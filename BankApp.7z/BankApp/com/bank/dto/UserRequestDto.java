package com.bank.dto;


import java.util.Objects;

public class UserRequestDto {

	private String firstName;
	private String lastName;
	private String panNo;
	private String regMobNum;
	private String regEmail;
	private String address;
	private String dob;
	private String gender;
	private int age;
	
	public UserRequestDto() {
		// TODO Auto-generated constructor stub
	}

	public UserRequestDto(String firstName, String lastName, String panNo, String regMobNum, String regEmail,
			String address, String dob, String gender, int age) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.panNo = panNo;
		this.regMobNum = regMobNum;
		this.regEmail = regEmail;
		this.address = address;
		this.dob = dob;
		this.gender = gender;
		this.age = age;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getRegMobNum() {
		return regMobNum;
	}

	public void setRegMobNum(String regMobNum) {
		this.regMobNum = regMobNum;
	}

	public String getRegEmail() {
		return regEmail;
	}

	public void setRegEmail(String regEmail) {
		this.regEmail = regEmail;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public int hashCode() {
		return Objects.hash(address, age, dob, firstName, gender, lastName, panNo, regEmail, regMobNum);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserRequestDto other = (UserRequestDto) obj;
		return Objects.equals(address, other.address) && age == other.age && Objects.equals(dob, other.dob)
				&& Objects.equals(firstName, other.firstName) && Objects.equals(gender, other.gender)
				&& Objects.equals(lastName, other.lastName) && Objects.equals(panNo, other.panNo)
				&& Objects.equals(regEmail, other.regEmail) && Objects.equals(regMobNum, other.regMobNum);
	}

	@Override
	public String toString() {
		return "UserRequestDto [firstName=" + firstName + ", lastName=" + lastName + ", panNo=" + panNo + ", regMobNum="
				+ regMobNum + ", regEmail=" + regEmail + ", address=" + address + ", dob=" + dob + ", gender=" + gender
				+ ", age=" + age + "]";
	}
	
	
	 
}
