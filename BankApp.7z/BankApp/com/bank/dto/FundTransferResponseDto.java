package com.bank.dto;

public class FundTransferResponseDto {

}
