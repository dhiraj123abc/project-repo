package com.bank.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bank.dto.BankStatementDto;
import com.bank.dto.FundTransferRequestDto;
import com.bank.dto.UserRequestDto;
import com.bank.entity.Account;
import com.bank.entity.Transaction;
import com.bank.entity.User;
import com.bank.repo.AccountRepository;
import com.bank.repo.TransactionRepository;
import com.bank.repo.UserRepository;
import com.bank.utility.Utility;

@Service
@Transactional
public class BankServiceImpl implements BankService {

	@Autowired
	private AccountRepository accountRepo;
	@Autowired
	private TransactionRepository transRepo;
	@Autowired
	private UserRepository userRepo;

	private final Utility utile = new Utility();

	@Override
	public String createUserAccount(UserRequestDto userReq) {
		String accountNumber = null;
		User user = new User();
		String userId = utile.generateUserId();
		BeanUtils.copyProperties(userReq, user);
		user.setUserId(userId);
		user.setCreatedDate(utile.getCurrentDate());
		user.setDob(userReq.getDob());
		userRepo.save(user);

		Account account = new Account();
		accountNumber = utile.generateAccountNumber();
		account.setAccountNumber(accountNumber);
		account.setAccountType("saving");
		account.setCreatedDate(utile.getCurrentDate());
		account.setInitialAmount(100000.00);
		account.setRegEmail(userReq.getRegEmail());
		account.setRegMob(userReq.getRegMobNum());
		account.setAccountBalance(100000.00);
		account.setUserId(userId);
		accountRepo.save(account);

		return "Account Created Successfully ,Your account number is :: " + accountNumber;
	}

	@Override
	public String fundTransfer(FundTransferRequestDto fundTransReq) {
		Transaction t1 = new Transaction();
		Transaction t2 = new Transaction();
		Double fromAccountBal = 0.0;
		Double toAccountBal = 0.0;
		Account fromAccount = accountRepo.findByAccountNumber(fundTransReq.getFromAccountNumber()).get(0);
		if (fromAccount.getAccountNumber() == null)
			return "From Account is not exist";
		Account toAccount = accountRepo.findByAccountNumber(fundTransReq.getToAccountNumber()).get(0);
		if (toAccount.getAccountNumber() == null)
			return "To Account is not exist";

		fromAccountBal = fromAccount.getAccountBalance() - fundTransReq.getAmount();
		t1.setAccountBalance(fromAccountBal);
		t1.setDebitAmount(fundTransReq.getAmount());
		t1.setFromAccount(fundTransReq.getFromAccountNumber());
		t1.setToAccount(fundTransReq.getToAccountNumber());
		t1.setTransDate(utile.getCurrentDate());
		t1.setTransID(utile.generateTransId());
		transRepo.save(t1);
		accountRepo.updateAccount(fromAccountBal, fundTransReq.getFromAccountNumber());

		toAccountBal = toAccount.getAccountBalance() + fundTransReq.getAmount();
		t2.setAccountBalance(toAccountBal);
		t2.setCreditAmount(fundTransReq.getAmount());
		t2.setFromAccount(fundTransReq.getFromAccountNumber());
		t2.setToAccount(fundTransReq.getToAccountNumber());
		t2.setTransDate(utile.getCurrentDate());
		t2.setTransID(utile.generateTransId());
		transRepo.save(t2);

		accountRepo.updateAccount(toAccountBal, fundTransReq.getToAccountNumber());
		return "Transaction completed Successfully";
	}

	@Override
	public List<BankStatementDto> getBankStatement(String date) {
		List<BankStatementDto> bankStatementList = new ArrayList<>();
		List<Transaction> findByTransDateBetween = null;
		List<String> dateList = null;
		String interval = date.toUpperCase();
		String[] tokens = interval.split("-");
		String month = tokens[0];
		String year = tokens[1];
		dateList = utile.getFromDateToDate(utile.getMonth(month), year);
		// findByTransDateBetween =
		// transRepo.findByTransDateBetween(dateList.get(0),dateList.get(1));
		findByTransDateBetween = transRepo.findByTransDateContains(dateList.get(0));

		// findByTransDateBetween =
		// transRepo.findByTransDateGreaterThanAndAgeLessThan(dateList.get(0),dateList.get(1));
		for (Transaction transaction : findByTransDateBetween) {
			BankStatementDto bankStatementDto = new BankStatementDto();
			BeanUtils.copyProperties(transaction, bankStatementDto);
			bankStatementList.add(bankStatementDto);
		}
		return bankStatementList;
	}

}
