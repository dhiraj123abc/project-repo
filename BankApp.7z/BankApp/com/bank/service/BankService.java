package com.bank.service;

import java.util.List;

import com.bank.dto.BankStatementDto;
import com.bank.dto.FundTransferRequestDto;
import com.bank.dto.UserRequestDto;
import com.bank.dto.UserResonseDto;

public interface BankService {

	   public String createUserAccount(UserRequestDto userReq);
	   public String fundTransfer(FundTransferRequestDto fundTransReq);
	   public List<BankStatementDto> getBankStatement(String timePeriod);
}
