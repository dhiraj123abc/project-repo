package com.bank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.dto.FundTransferRequestDto;
import com.bank.service.BankService;

@RestController
@RequestMapping("/fundTransfer")
public class FundTransferController {

	@Autowired
	BankService bankService;
	
	@PostMapping("/transfer")
	public ResponseEntity<String> createUser(@RequestBody FundTransferRequestDto userRequest){
		       String message=bankService.fundTransfer(userRequest);
		       return new ResponseEntity<String>(message,HttpStatus.OK);
	}
}
