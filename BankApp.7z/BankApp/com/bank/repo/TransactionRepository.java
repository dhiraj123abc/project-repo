package com.bank.repo;





import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.bank.entity.Transaction;


public interface TransactionRepository extends JpaRepository<Transaction, String> {

	public List<Transaction> findByTransDateContains(String start);
	
}
