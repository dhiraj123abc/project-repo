package com.bank.in.onlineBanking.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bank.in.onlineBanking.model.User;
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	
	
	
	

}
