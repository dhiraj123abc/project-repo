package com.bank.in.onlineBanking.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bank.in.onlineBanking.model.User;
import com.bank.in.onlineBanking.model.UserDto;
import com.bank.in.onlineBanking.model.Transaction;
import com.bank.in.onlineBanking.service.UserService;

@RestController
public class UserController {
	@Autowired
	UserService userservice;
	@Autowired
	TransactionController transactionController;

	@GetMapping("/getAll")
	public List<User> getAllUserAccounts() {
		return userservice.getAllUserAccounts();

	}
	@GetMapping("/accountNumber/{id}")
	public Optional<User> getByUserAccount(@PathVariable("id") Long id) {
		return userservice.getByUserAccount(id);

	}
	

	@PostMapping("/register")
	public User userRegistration(@Valid @RequestBody User user) {
		transactionController.createAccount(user.getAccountNumber(), 0L, user.getStatus());
		return userservice.userRegistration(user);

	}

	@PostMapping("/transfer")
	public void transfer(@RequestParam Long senderAccountNumber, @RequestParam Long receiverAccountNumber,
			@RequestParam Long amount) {
//	User user= new User();
//	Long balance = user.getBalanceAmount();
//	if(accountNumber.equals(user.getAccountNumber())) {
//		if(amount<= balance) {
//		 balance=balance-amount;
//		user.setBalanceAmount(balance);
//		
//	}
		userservice.transfer(senderAccountNumber, receiverAccountNumber, amount);

	}

}
