package com.bank.in.onlineBanking.model;

public class UserDto {
	
	private String firstName;
	private String lastName;
	private String age;
	private String panNumber;
	private String email;
	private String gender;
	private Long phoneNumber;
	private Long balanceAmount;
	public UserDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserDto(String firstName, String lastName, String age, String panNumber, String email, String gender,
			Long phoneNumber, Long balanceAmount) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.panNumber = panNumber;
		this.email = email;
		this.gender = gender;
		this.phoneNumber = phoneNumber;
		this.balanceAmount = balanceAmount;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Long getBalanceAmount() {
		return balanceAmount;
	}
	public void setBalanceAmount(Long balanceAmount) {
		this.balanceAmount = balanceAmount;
	}
	@Override
	public String toString() {
		return "UserDto [firstName=" + firstName + ", lastName=" + lastName + ", age=" + age + ", panNumber="
				+ panNumber + ", email=" + email + ", gender=" + gender + ", phoneNumber=" + phoneNumber
				+ ", balanceAmount=" + balanceAmount + "]";
	}
	
	

}
