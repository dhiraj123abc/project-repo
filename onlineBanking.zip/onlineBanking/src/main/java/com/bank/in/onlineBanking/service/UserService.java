package com.bank.in.onlineBanking.service;

import java.util.List;
import java.util.Optional;

import com.bank.in.onlineBanking.model.User;
import com.bank.in.onlineBanking.model.UserDto;
import com.bank.in.onlineBanking.model.Transaction;

public interface UserService {
	List<User> getAllUserAccounts();

	User userRegistration(User user);

	User transfer(Long accountNumber, Transaction usertxn);

	void transfer(Long senderAccountNumber, Long receiverAccountNumber, Long amount);

	Optional<User> getByUserAccount(Long id);

}
