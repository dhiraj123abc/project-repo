package com.bank.in.onlineBanking.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.Hidden;

@Entity
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Hidden
	private Long accountNumber;
	@NotNull
	@Size(min = 2, max = 20)
	private String firstName;
	private String lastName;
	@Size(min = 2, max = 2)
	private String age;
	private String panNumber;
	@Email
	private String email;
	private String gender;

	private Long phoneNumber;
	
	private String status;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(Long accountNumber, String firstName, String lastName, String age, String panNumber, String email,
			String gender, Long phoneNumber,  String status) {
		super();
		this.accountNumber = accountNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.panNumber = panNumber;
		this.email = email;
		this.gender = gender;
		this.phoneNumber = phoneNumber;
	//	this.balanceAmount = balanceAmount;
		this.status = status;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

//	public Long getBalanceAmount() {
//		return balanceAmount;
//	}
//
//	public void setBalanceAmount(Long balanceAmount) {
//		this.balanceAmount = balanceAmount;
//	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "User [accountNumber=" + accountNumber + ", firstName=" + firstName + ", lastName=" + lastName + ", age="
				+ age + ", panNumber=" + panNumber + ", email=" + email + ", gender=" + gender + ", phoneNumber="
				+ phoneNumber + ", balanceAmount="  + ", status=" + status + "]";
	}

}
