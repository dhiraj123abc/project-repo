package com.bank.in.onlineBanking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.in.onlineBanking.model.Transaction;
import com.bank.in.onlineBanking.model.User;
import com.bank.in.onlineBanking.repository.TransactionRespository;

@Service
public class TransactionService {
	@Autowired
	TransactionRespository transactionRespository;
	public Transaction createAccount(Transaction transaction) {
		return transactionRespository.save(transaction);
		
	}
	public Long getbalanceByAccountId(Long id) {
		// TODO Auto-generated method stub
		return transactionRespository.getbalanceByAccountId(id);
	}
	public void depositAmount(Long id, Long initBal) {
		// TODO Auto-generated method stub
		transactionRespository.depositAmount(id,initBal);
	}
	public void withdrawAmount(Long acctID, Long availBal) {
		transactionRespository.withdrawAmount(acctID,availBal);
		
	}
	public void transferAmount(Long acctID, Long destAcctID, Long amount) {
		transactionRespository.withdrawAmount(acctID, amount);
		transactionRespository.depositAmount(destAcctID, amount);
		
	}

}
