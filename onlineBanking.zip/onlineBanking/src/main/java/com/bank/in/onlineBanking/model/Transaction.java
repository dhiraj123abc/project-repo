package com.bank.in.onlineBanking.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
@Entity
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long accountNumber;
	private Long balance;
	private String acctStatus;
//	private Date fromDate;
//	private Date toDate;
	
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(Long accountNumber, Long balance, String acctStatus) {
		super();
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.acctStatus = acctStatus;
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Long getBalance() {
		return balance;
	}
	public void setBalance(Long balance) {
		this.balance = balance;
	}
	public String getAcctStatus() {
		return acctStatus;
	}
	public void setAcctStatus(String acctStatus) {
		this.acctStatus = acctStatus;
	}
	@Override
	public String toString() {
		return "Transaction [accountNumber=" + accountNumber + ", balance=" + balance + ", acctStatus=" + acctStatus
				+ "]";
	}

	
}
