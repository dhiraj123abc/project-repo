package com.bank.in.onlineBanking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.in.onlineBanking.model.User;
import com.bank.in.onlineBanking.model.UserDto;
import com.bank.in.onlineBanking.model.Transaction;
import com.bank.in.onlineBanking.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepository repository;

	@Override
	public List<User> getAllUserAccounts() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	

	@Override
	public User transfer(Long accountNumber, Transaction usertxn) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public void transfer(Long senderAccountNumber, Long receiverAccountNumber, Long amount) {
//		// TODO Auto-generated method stub
//		User user1 = new User();
//		User user2 = new User();
//		if (repository.findById(senderAccountNumber) != null && repository.findById(receiverAccountNumber) != null) {
//			try {
//
//				Long balanceRemain = user1.getBalanceAmount() - amount;
//				Long credit = user2.getBalanceAmount() + amount;
//				user1.setBalanceAmount(balanceRemain);
//				user2.setBalanceAmount(credit);
//				repository.save(user1);
//				repository.save(user2);
//
//			} catch (Exception exc) {
//				System.out.println("exce" + exc.getMessage());
//			}
//		} else {
//			System.out.println("somthing wrong ");






	@Override
	public User userRegistration(User user) {
		// TODO Auto-generated method stub
		return repository.save(user);
	}



	@Override
	public Optional<User> getByUserAccount(Long id) {
		// TODO Auto-generated method stub
		return repository.findById(id);
	}



	@Override
	public void transfer(Long senderAccountNumber, Long receiverAccountNumber, Long amount) {
		// TODO Auto-generated method stub
		
	}



		

}
