package com.bank.in.onlineBanking.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.in.onlineBanking.model.Transaction;
import com.bank.in.onlineBanking.model.User;
import com.bank.in.onlineBanking.service.TransactionService;


@RestController
public class TransactionController {
	@Autowired
	TransactionService transactionService;
	public static final Logger logger = LoggerFactory.getLogger(TransactionController.class);

	public Transaction createAccount(Long aacId, Long balance, String accStatus) {
		logger.debug("==================> account created");
		Transaction transaction = new Transaction(aacId, balance, accStatus);
		return transactionService.createAccount(transaction);

	}

	@GetMapping("/accountNumber/{id}/balance")
	public Long getbalanceByAccountId(@PathVariable("id") Long id) {
		return transactionService.getbalanceByAccountId(id);

	}

	@PutMapping("/account/{id}/deposit/{amount}")
	public void depositAmount(@PathVariable Long id, @PathVariable Long amount) {
		Long initBal = getbalanceByAccountId(id);
		initBal = initBal + amount;
		transactionService.depositAmount(id, initBal);

	}

	@PutMapping("/account/{acctID}/withdraw/{amount}")
	public void withdrawAmount(@PathVariable Long acctID, @PathVariable Long amount) {
		//Long initBal = getbalanceByAccountId(acctID);
		
		transactionService.withdrawAmount(acctID, amount);

	}

	@PutMapping("/account/{acctID}/transfer/{destAcctID}/{amount}")
	public void transferAmount(@PathVariable Long acctID, @PathVariable Long destAcctID, @PathVariable Long amount) {
		Long initBalSender = getbalanceByAccountId(acctID);
		Long initBalReceiver = getbalanceByAccountId(destAcctID);
//		initBalSender = initBalSender - amount;
//		initBalReceiver = initBalReceiver + amount;
		transactionService.transferAmount(acctID, destAcctID, amount);

	}
}
