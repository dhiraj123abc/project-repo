package com.bank.in.onlineBanking.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.bank.in.onlineBanking.model.Transaction;

public interface TransactionRespository extends JpaRepository<Transaction, Long> {
	@Query(value = "select balance from transaction where account_number=:id", nativeQuery = true)
	Long getbalanceByAccountId(Long id);

	@Modifying
	@Transactional
	@Query("update Transaction set balance = balance+?2 where accountNumber=?1")
	void depositAmount(Long id, Long initBal);

	@Modifying
	@Transactional
	@Query("update Transaction set balance= balance-?2 where accountNumber=?1")
	void withdrawAmount(Long acctID, Long availBal);

}
