package collection;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Arraylist_vs_Linkedlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> arrayList = new ArrayList<String>();
		LinkedList<String> linkedList = new LinkedList<String>();
		System.out.println("adding the elements");
		Instant start = Instant.now();
		add(arrayList);
	
		Instant end = Instant.now();
		System.out.println(" strat to end " + Duration.between(start, end));
		Instant start1 = Instant.now();
		add(linkedList);
	
		Instant end1 = Instant.now();
		System.out.println(" strat to end " + Duration.between(start1, end1));
		System.out.println();
		


		System.out.println("retreving the elements");
		Instant start2 = Instant.now();
		get(arrayList);
		Instant end2 = Instant.now();
		System.out.println(" strat to end " + Duration.between(start2, end2));
		Instant start3 = Instant.now();
		get(linkedList);
	
		Instant end3 = Instant.now();
		System.out.println(" strat to end " + Duration.between(start3, end3));

	}

	static void add(List<String> list) {
		for (int i = 0; i < 10000; i++) {

			list.add(0, "dhiraj");
			list.add(0, "deju");
			list.add(0, "rama");
			list.add(0, "hari");

		}
	}

	static void get(List<String> list) {
		for (int i = 0; i < 10000; i++) {

			list.get(i);

		}
		// linkedlist takes less time to add on the same element position

	}

}
