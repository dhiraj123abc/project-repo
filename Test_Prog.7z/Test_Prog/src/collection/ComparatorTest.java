package collection;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class ComparatorTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Company> list = new LinkedList<>();
		list.add(new Company("canda", "HCL"));
		list.add(new Company("Anda", "etch"));
		list.add(new Company("danda", "bitwise"));
		list.add(new Company("banda", "BNP"));
		
		Comparator<Company> companyname= new Comparator<Company>() {
			
			@Override
			public int compare(Company o1, Company o2) {
				// TODO Auto-generated method stub
				return o1.getName().compareTo(o2.getName());
			}
		};
		
		//Collections.sort(list, companyname);
		Collections.sort(list, companyname);
		
		for(Company c :list) {
			
			System.out.println("" +c);
		}
		
		System.out.println("BY Counrty sort compare");
	
	Comparator<Company> countryname= new Comparator<Company>() {
	@Override
	public int compare(Company o1, Company o2) {
		// TODO Auto-generated method stub
		return o1.getCountry().compareTo(o2.getCountry());
	}};

	// Collections.sort(list, companyname);
	Collections.sort(list, countryname);

	for(Company c:list)
	{

		System.out.println("" + c);
	}

}

}


