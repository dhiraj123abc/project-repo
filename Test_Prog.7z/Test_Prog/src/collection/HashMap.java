package collection;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMap {

	public static void main(String[] args) {
		
	    StringBuffer sb1 = new StringBuffer("1");
	StringBuffer sb2 = new StringBuffer("1");

	java.util.HashMap<StringBuffer, String> map = new java.util.HashMap<>();
			map.put(sb1, "HCL");
	map.put(sb2, "HCL");
	System.out.println(map);
	for(Object entry1 : map.entrySet()) {
		System.out.println(" "+ entry1);
		
	}

	System.out.println(" "+map.put(sb1, "HCL"));
	
	System.out.println(" -----------------");

		// TODO Auto-generated method stub
		java.util.HashMap<Integer, String> hm = new java.util.HashMap<Integer, String> ();
		hm.put(1, "shiba");
		hm.put(2, "shiba");
		hm.put(3, "shiba");
		hm.put(1, "good");
		hm.put(8, "shiba");
		hm.put(1, "shiba");
		hm.put(1, "shiba");
		hm.put(1, "good");
		System.out.println(" " + hm);
		System.out.println(" " +hm.get(1));
		System.out.println(" " +hm.keySet());
		System.out.println(" " +hm.values());
		System.out.println(" " +hm.entrySet());
		
		for(Object entry : hm.entrySet()) {
			System.out.println(" "+ entry);
			
		}
		
		Set<Entry<Integer, String>> set=hm.entrySet();
		
		Iterator itr = set.iterator();
		while(itr.hasNext()) {
			System.out.println(" from iterator");
			Map.Entry<Integer, String> entry =(Entry<Integer, String>) itr.next();
			System.out.println(" "+ entry.getKey()+" "+ entry.getValue() );
			
		}
		
		//System.out.println("' "+ set);
		
		

	}

}
