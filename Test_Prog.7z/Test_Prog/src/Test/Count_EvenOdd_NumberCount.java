package Test;

public class Count_EvenOdd_NumberCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number =11111;
		int even_couont=0;
		int odd_count=0;
		
		while(number>0) {
			
		int rem = number%10;
		
		if(rem%2==0) {
			even_couont++;
			
			
		}
		else {
			odd_count++;
			
		}
	number=	number/10;
		
		}
		
		System.out.println(even_couont);
		System.out.println(odd_count);
		

	}

}
