package Test;

public class Reverse_String {

	public static void main(String[] args) {
		String s ="slenium_java" ;
		String rev="";
		String rev1="";
		char a[]=s.toCharArray();
		int len=a.length;
		
		
		for(int i=s.length()-1;i>=0;i--) {
			
	 	rev=rev+ s.charAt(i) ;
		
		}
		for(int i = len-1;i>=0 ;i-- ) {
			
			rev1= rev1+ a[i];
		}
		
		
		
		System.out.println(""+rev);
		System.out.println(""+rev1);
		
		
	}

}
