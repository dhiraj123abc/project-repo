package Test;

import java.util.Scanner;

public class Count_SumOfNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new java.util.Scanner(System.in);
		System.out.println("enter a numer ");
		int i = sc.nextInt();
		//int i = 12345;
		int sum =0;
		while(i>0) {
			sum= sum+i%10; 
			//sum= sum*10+i%10;  // just reverse the number *10
			i=i/10;
			
		}
		System.out.println(sum);

	}

}
