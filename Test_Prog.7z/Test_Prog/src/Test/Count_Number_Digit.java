package Test;

import java.util.Scanner;

public class Count_Number_Digit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new java.util.Scanner(System.in);
		System.out.println("enter a numer ");
		int i = sc.nextInt();
		//int i =12301540;
		int count =0;
		
		while(i>0) {
			i= i/10;
			count++;
			
		}

		System.out.println(count);
	}

}
