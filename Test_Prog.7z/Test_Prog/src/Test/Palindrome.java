package Test;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("enter number ");
	int number =	sc.nextInt();
	sc.nextLine();
	int original_number= number;
	int reverse=0;
	
	while(number!=0) {
		reverse=	reverse*10+ number%10;
	number=	number/10;
		
	}
	System.out.println(reverse);
	
	if(reverse==original_number) {
		System.out.println("number is paindrome ");
		
	}
	else {
		System.out.println("number is not  paindrome ");
	}	
	sc.nextLine();

	}

}
