package Test;

public class Check_Prime_Number_or_not {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n =10;
		int count =0;
		
		
		for (int i=0; i<=n;i++) {
			 if (n%10==0) {
				 count++;
			 }
			 
			
		}
		if(count<=2) {
			System.out.println("its prime number ");
		}
		else {
			System.out.println("its prime not number ");
		}

	}

}
