package Test;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Scanner sc= new java.util.Scanner(System.in);
	System.out.println("enter a numer ");
	int number = sc.nextInt();
	int rev =0;
	 while (number!=0) {
		 rev = rev*10 +number%10; // 0+4=4  4*10+3=43  43*10+2=432 432*10+1= 4321
          number = number/10;	//123 12	 
		 
	 }
	 System.out.println(rev);
	
	}

}
