package Test;

public class Swap_Number {

	public static void main(String[] args) {
		int a =10 ;
		int b=20;
		//using third variable 
//		int c=a;
//		 a=b;
//		 b=c;
//		 
		//without using third variable 
		a=a+b;
		b=a-b;
		a=a-b;
		
		
		 System.out.println("value is swapped "+ "a=" +a  + "b="+ b);

	}

}
