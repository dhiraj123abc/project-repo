package Test;

import java.util.Scanner;

public class Palindrome_String_Check {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc  = new Scanner(System.in);
		System.out.println("enter string");
		String original_string =sc.nextLine();
		
		String rev="";
		 for (int i=original_string.length()-1; i>=0;i--) {
				rev=rev+ original_string.charAt(i) ;
		 }
		// System.out.println(rev);
       if (original_string.equals(rev)) {
    	   System.out.println("string is palindrome");
    	   
       }
       else {
    	   System.out.println("not palindrome string");
       }
	}

}
