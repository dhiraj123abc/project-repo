package Test;

import java.util.Scanner;

public class Ternary_Operator_LargestNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new java.util.Scanner(System.in);
		System.out.println("enter numer A ");
		int a = sc.nextInt();
		
		System.out.println("enter numer B");
		int b = sc.nextInt();
		
		
		System.out.println("enter numer C ");
		int c = sc.nextInt();
		
		//Ternary operator 
	//	int largest = a>b?a:b;   // if a greater then b returns a else b  after ? 
	//	int largest1= c>largest?c:largest;  // if c greater then (largest) return c or largest 
	
		//in single line ternary operator 
		int largest2 = c>(a>b?a:b)?c:(a>b?a:b);
		System.out.println("largest number is "+ largest2);

	}

}
