package Test;

public class Fibbonaci_series {

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		int a = 0;
		int b = 1;
		int sum = 0;

		// System.out.println(a+ " "+b);
		for (int i = 0; i < 10; i++) {
			sum = a + b; // 1 2 3 5 8 13

			System.out.print(" " + sum); // 1 2 3 5 8 13
			a = b; // a= 1 1 2 3 5
			b = sum; // b = 1 2 3 5 8

		}
		System.out.println();
		int result = fib(4);
		System.out.println("difference with previous " + result);
	}

	static int fib(int n) {
		if (n == 1 || n == 2) {
			return n - 1;
		}
		return fib(n - 1) + fib(n - 2);

	}
}
