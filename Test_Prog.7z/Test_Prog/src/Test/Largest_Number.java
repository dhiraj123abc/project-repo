package Test;

import java.util.Scanner;

public class Largest_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new java.util.Scanner(System.in);
		System.out.println("enter numer A ");
		int a = sc.nextInt();
		
		System.out.println("enter numer B");
		int b = sc.nextInt();
		
		
		System.out.println("enter numer C ");
		int c = sc.nextInt();

		if(a>b && a>c) {
			System.out.println(a+" is greater");
			
		}
		if(b>a && b>c) {
			System.out.println(b+" is greater");
			
		}
		else {
			System.out.println(c+" is greater");
		}
	}

}
