package java_practice_Harry;

public class Dry_run {

	static int sum(int x ,int... arr) {
		int result = 0;
		for (int a : arr) {
			result += a;

		}
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("" + sum(100000,5,2));  // 7

	}

}
