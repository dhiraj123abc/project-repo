package java_practice_Harry;

import java.util.Random;
import java.util.Scanner;

public class Rock_Paper_Scissor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int min = 1;
		int max = 3;

		Scanner sc = new Scanner(System.in);
		System.out.println("Select \n 1 for rock \n 2 for papper \n 3 for sicssor ");
		int user = sc.nextInt();
		int computer = (int) (Math.random() * (max - min + 1) + min);
		if (user == 1 && computer == 2 || user == 2 && computer == 3 || user == 3 && computer == 1) {
			System.out.println("You win");
			System.out.println("computer selected" + computer);

		} 
		else if (user == computer) {
			System.out.println("its a tie");

			System.out.println("computer selected" + computer);

		}
		else {
			System.out.println("You loose");
			System.out.println("computer selected" + computer);
		}
	}

}
