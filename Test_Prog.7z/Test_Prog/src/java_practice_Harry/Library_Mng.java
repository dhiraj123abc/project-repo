package java_practice_Harry;

import java.util.ArrayList;

class Book {
	String name, author;

	public Book(String name, String author) {
		super();
		this.name = name;
		this.author = author;
	}

	@Override
	public String toString() {
		return "Book [name=" + name + ", author=" + author + "]";
	}

}

class Library {
	public ArrayList<Book> books;

	public Library(ArrayList<Book> books) {
		// TODO Auto-generated constructor stub
//		for (Book b : books) {
//			this.books = books;
//		}
		this.books = books;
	}

	public void addBook(Book book) {
		System.out.println("book added" + book);
		this.books.add(book);

	}

	public void returnBook(Book book) {
		System.out.println("book return" + book);
		this.books.add(book);

	}

	public void issuBook(Book book) {
		System.out.println("book issued" + book);
		this.books.remove(book);

	}
}

public class Library_Mng {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Book> br = new ArrayList<>();
		Book book1 = new Book("algoexpert", "brick");
		br.add(book1);

		Book book2 = new Book("java", "harry");
		br.add(book2);

		Book book3 = new Book("spring", "durgesh");
		br.add(book3);


		br.add(new Book("algoexpert2", "brick"));

		br.add(new Book("java2", "harry"));

		br.add(new Book("springboot2", "danish"));
		Library library = new Library(br);

		library.addBook(new Book("hava", "hah"));
		System.out.println(" " + library.books);
		library.issuBook(book3);
		System.out.println(" " + library.books);
		library.returnBook(book3);
		System.out.println(" " + library.books);

	}

}
