package java_practice_Harry;

class Employee {
	int salary;
	int id;
	String name;

	public int getSalary() {
		return salary;

	}

	public void setSalary(int n) {

		salary = n;

	}

	void profile() {
		System.out.println("profile\n" + name + " " + salary + " " + id);

	}

}

public class Basic_Class_emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee jhon = new Employee();
		jhon.id = 1;
		jhon.name = "JHON Daniels";
		jhon.salary = 28000;
		// jhon.profile();
		jhon.setSalary(50000);
		System.out.println(jhon.getSalary());

		int i = 5;
		i = i--;
		int j = i;
		System.out.println(" j=" + i);
		i--;
		System.out.println(" j=" + i);

	}

}
