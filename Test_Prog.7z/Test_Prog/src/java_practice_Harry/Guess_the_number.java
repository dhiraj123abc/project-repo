package java_practice_Harry;

import java.util.Random;
import java.util.Scanner;

public class Guess_the_number {
	int numberOfGuess = 3;

	public int getNumberOfGuess() {
		// int numberOfGuess = numberOfGuess-- ;

		return numberOfGuess--;
	}

	public void setNumberOfGuess(int numberOfGuess) {
		this.numberOfGuess = numberOfGuess;
	}

	Guess_the_number() {

	}

	void result() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Select numer");
		int user = sc.nextInt();
		Random rnd = new Random();

		int computer = rnd.nextInt(3);
		if (user == computer) {
			Boolean isCorrect = true;

			System.out.println("guess is correct");

		} else {
			System.out.println("computer selected " + computer);

			System.out.println("wrong Guess");
			System.out.println("num of guess remaining" + getNumberOfGuess());
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Boolean isCorrect = false;
//		while (!isCorrect) {
//			Guess_the_number number = new Guess_the_number();
//			number.result();
//			number.getNumberOfGuess();
		Game game= new Game();
		boolean b=false;
		//game.inputNumber();
		while(!b) {
			game.inputNumber();
          b= game.isCorrect();
	System.out.println(" "+ b);
		
		

		}

	}
}

	class Game {
		int number;
		int userInput;
		int numberOfGuess;

		 Game() {
			//super();

			Random rnd = new Random();
			this.number = rnd.nextInt(3);

			// TODO Auto-generated constructor stub
		}

		public int getNumber() {
			return number;
		}

		

		public int getUserInput() {
			return userInput;
		}

		public void setUserInput(int userInput) {

			this.userInput = userInput;
		}

		public int getNumberOfGuess() {
			return numberOfGuess;
		}

		public void setNumberOfGuess(int numberOfGuess) {
			this.numberOfGuess = numberOfGuess;
		}

		int  inputNumber() {
			System.out.println("eneter number");
			Scanner sc = new Scanner(System.in);

			userInput = sc.nextInt();
			return userInput;
			

		}

		boolean isCorrect() {
			if (userInput == number) {
				return true;

			} 
				return false;
			

		}

	}




