package java_practice_Harry;

class InvalidInputException extends Exception {
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "nahiho sakta ";
	}

//	@Override
//	public String getMessage() {
//		// TODO Auto-generated method stub
//		return "sorry 11 and 17 inputs cannot be added";
//	}

}

class InvaliDivisionException extends Exception {
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "0 se divide maat kar  ";
	}

//	@Override
//	public String getMessage() {
//		// TODO Auto-generated method stub
//		return "sorry 11 and 17 inputs cannot be added";
//	}

}

class MultiException extends Exception {
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "0 se multif maat kar  ";
	}

}

class calculator {
	double add(double a, double b) throws InvalidInputException {
		if (a == 11 && b == 17) {
			throw new InvalidInputException();

		}
		return a + b;

	}

	double divide(double a, double b) throws InvaliDivisionException {
		if (b == 0) {
			throw new InvaliDivisionException();
		}
		return a / b;
	}

	double multiplication(double a, double b) throws MultiException {
		if (a == 0 || b == 0) {
			throw new MultiException();

		}
		return a * b;

	}
}

public class Custom_Calculattor {

	public static void main(String[] args) throws InvalidInputException, InvaliDivisionException, MultiException {
		// TODO Auto-generated method stub
		calculator cl = new calculator();
		// cl.add(11, 17);
		//System.out.println(cl.divide(15, 0));
		System.out.println(cl.multiplication(0, 150));
	}

}
