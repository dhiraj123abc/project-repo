package pattern;

public class Character_Patter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// A=65 Ascii value
		// B=66
//		char i,j;
//		for(i='A';i<='E';i++) {
//			
//			for(j=1;j<=5;j++) {
//				
//				System.out.print(" "+ i);
//				
//			}
//			System.out.println();
//		}

//		for(int i=65;i<=69;i++) {
//			
//			for(int j=1;j<=5;j++) {
//				
//				System.out.print(" "+ (char)(i));
//				
//			}
//			System.out.println();
//		}

//		for(int j=1;j<=5;j++) {
//			
//			for(int i=65;i<=69;i++) {
//				
//				System.out.print(" "+ (char)(i));
//				
//			}
//			System.out.println();
//		}
//		

		for(int i=69;i>=65;i--) {
			
			for(int j=1;j<=5;j++) {
				
				System.out.print(" "+ (char)(i));
				
			}
			System.out.println();
		}
		for (int i = 69; i >= 65; i--) {

			for (char j = 'E'; j >= 'A'; j--) {

				System.out.print(" " +  j);

			}
			System.out.println();
		}

	}

}
