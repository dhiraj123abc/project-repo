package pattern;

public class Pattern_ifelse_logics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		for (int i = 1; i <= n; i++) {

			for (int j = n; j >= 1; j--) {

				if (i >= j) {
					System.out.print("*");

				} else
					System.out.print(" ");
			}
			System.out.println();

		}

		System.out.println();

		for (int a = n; a >= 1; a--) {

			for (int b = n; b >= 1; b--) {

				if (a >= b) {
					System.out.print("*");

				} else
					System.out.print(" ");
			}
			System.out.println();

		}
		n = 5;
		int px = n;
		int py = n;

		for (int i = 1; i <= n; i++) {
			for (int j = 1; j < n * 2; j++) {

				if (j == px || j == py) {
					System.out.print("*");

				} else {
					System.out.print(" ");
				}

			}
			px--;
			py++;

			System.out.println();

		}

		px = 1;
		py = 9;

		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= 9; j++) {
				if (j == px || j == py) {
					System.out.print(i);
				} else {
					System.out.print(" ");
				}

			}
			px++;
			py--;
			System.out.println();

		}

	}
}
