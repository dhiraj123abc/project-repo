package pattern;

public class Pyramid_ifelese_logic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 4;
		int x = n;
		int y = n;

		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n * 2; j++) {

				if (j >= x && j <= y) {
					System.out.print("*");

				} else {
					System.out.print(" ");
				}

			}
			x--;
			y++;
			System.out.println();

		}
		x = 1;
		y = (n * 2)-1;

		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n * 2; j++) {

				if (j >= x && j <= y) {
					System.out.print("*");

				} else {
					System.out.print(" ");
				}

			}
			x++;
			y--;
			System.out.println();

		}
	}

}
