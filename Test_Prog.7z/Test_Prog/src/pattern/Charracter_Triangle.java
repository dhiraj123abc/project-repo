package pattern;

public class Charracter_Triangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (char i = 'A'; i <= 'E'; i++) {

			for (char j = 'A'; j <= i; j++) {
				System.out.print(" " + i);

			}
			System.out.println();
		}
		for (char i = 'A'; i <= 'E'; i++) {

			for (char j = 'A'; j <= i; j++) {
				System.out.print(" " + j);

			}
			System.out.println();
		}
	}

}
