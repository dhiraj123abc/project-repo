package pattern;

public class Reverse_Pyramid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int n = 5;
//		
//		for (int i=1;i<=5;i++) {
//			for(int k=1;k<=i ;k++) {
//				System.out.print(" ");
//				
//			}
//			for (int j=5; j>=i;j--) {
//				System.out.print("* ");
//			}
//			System.out.println();
//			
//////			System.out.println();
//	}
//		
		int n=5;
		for (int i=n;i>=1 ; i--) {
			
			for(int j=n-1; j>=i;j--) {
				System.out.print(" ");
				
			}
			for(int k = 1;k<=i;k++) {
				System.out.print("* ");
				
			}
			System.out.println();
			
		}
	//	int n=5;
		int z=7;
		
		for (int i=n;i>=1 ; i--) {
			
			for(int j=n-1; j>=i;j--) {
				System.out.print(" ");
				
			}
			for(int k =1;k<=z;k++) {
				System.out.print("*");
				
			}
			z-=2;
			System.out.println();
			
		}
		
		
		
	}

	

}
