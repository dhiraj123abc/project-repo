package pattern;

import java.util.Scanner;

public class Alphabates_starpattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stubport java.util.Scanner;

		int k = 5;

		for (int i = 1; i <= k; i++) {

			for (int j = 1; j <= k; j++) {
				if (j == i || j==k-i+1)
					System.out.print("*");
				System.out.print(" ");

			}

			System.out.println();

		}

	}
}
