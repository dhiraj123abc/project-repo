package pattern;

public class Simple_Pattern {

	public static void main(String args[]) {
		for (int i = 1; i <= 5; i++) {

			for (int j = 1; j <= i; j++) {
				System.out.print("*");

			}
			System.out.println();

		}

		System.out.println();

		int n = 3;

		for (int i = n; i >= -n; i--) {

			for (int j = n; j >= Math.abs(i); j--) {
				System.out.print("*");

			}
			System.out.println();
		}
		int p = 1;

		for (int i = n; i >= -n; i--) {

			for (int j = 1; j <= Math.abs(i); j++) {
				System.out.print(" ");

			}
			
			for (int k = 3; k >= Math.abs(i); k--) {
				System.out.print(p + " "); //4 

			}
			if (i > 0) {
				p++;

			} else {
				p--;
			}
			System.out.println();
		}
	}
}
