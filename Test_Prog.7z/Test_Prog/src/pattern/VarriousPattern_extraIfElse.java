package pattern;

public class VarriousPattern_extraIfElse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n = 5;
		for(int i=1;i<=n;i++) {
			
			for(int j= 1;j<=n;j++) {
				
				if (i==(n/2)+1 || j==(n/2)+1) {
					System.out.print("*");
				}else {
				System.out.print("0");
			}
			
			
		}
			System.out.println();
	}
	
	
	
	for(int a =1;a<=n;a++) {
		for(int b=1;b<=n;b++) {
			 if (a==b || b==(n-a)+1) {
				 System.out.print("*");
		}
			 else {
				 System.out.print(" ");
				 }
			 }
		System.out.println();
			 
			
		}
	
	
	for(int c =1;c<=n;c++) {
		for(int d =1;d<=n;d++) {
			
			if (c==1||c==n||d==1||d==n) {
				
				System.out.print("*");
			}
			else {
				System.out.print(" ");
			}
			
		}
		System.out.println();
		
	}
	
		
	}
	
}


