package pattern;
import java.lang.Math;



public class Pyramid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n=4; 
int z=1;
		for (int i=1;i<=n ; i++) {
			
			for(int j=n-1; j>=i;j--) {
				System.out.print(" ");
				
			}
			for(int k = 1;k<=i;k++) {
				System.out.print(" *");
				
			}
			System.out.println();
			
		}
for (int i=1;i<=n ; i++) {
			
			for(int j=n-1; j>=i;j--) {
				System.out.print(" ");
				
			}
			for(int k = 1;k<=z;k++) {
				System.out.print(Math.abs(k-i));
				
			}
			z=z+2;
			System.out.println();
			
		}
for (int i=1;i<=n ; i++) {
	
	for(int j=n-1; j>=i;j--) {
		System.out.print(" ");
		
	}
	for(int k = (i-1);k>=-(i-1);k--) {
		System.out.print(i-Math.abs(k));
		
	}
	//z=z+2;
	System.out.println();
	
}
	}

}
