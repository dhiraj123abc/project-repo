package pattern;

public class Reverse_rightangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int i=1;i<=5;i++) {
			
			for(int j=5;j>=i;j--) {
				System.out.print("*");
				
			}
			System.out.println();
			
		}

		
		for(char i='A';i<='E';i++) {
			for(char j='E';j >=i;j--) {
				System.out.print(" "+ i);
				 
			}
			System.out.println();
			
		}
		for(char i='A';i<='E';i++) {
			for(char j='E';j >=i;j--) {
				System.out.print(" "+ j);
				 
			}
			System.out.println();
			
		}
		
		for(char i='E';i>='A';i--) {
			for(char j='A';j <=i;j++) {
				System.out.print(" "+ j);
				 
			}
			System.out.println();
			
		}
		
	}

}
