package arrays;

public class Reverse_Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		int length= arr.length;
		
		int median = Math.floorDiv(length, 2);
		System.out.println("median \t" + median);

		for (int i = 0; i <= median; i++) {
			int temp =arr[i];
			arr[i]=arr[length-i-1];
			arr[length-i-1]=temp;
			

		}
		System.out.println("reversed arrays");
		for(int element: arr) {
			System.out.print(" "+ element);
		}

	}
}
