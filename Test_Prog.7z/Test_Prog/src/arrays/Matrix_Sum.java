package arrays;

public class Matrix_Sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// int[][] mtx1 = new int[2][3];

		int[][] mtx1 = { { 1, 2, 3 }, { 4, 5, 6 } };
		int[][] mtx2 = { { 1, 2, 3 }, { 4, 5, 6 } };
		// int sum = 0;
		int[][] result = { { 0, 0, 0 }, { 0, 0, 0 } };
		for (int i = 0; i < mtx1.length; i++) {
			for (int j = 0; j < mtx1[i].length; j++) {
				// System.out.print(result[i][j] + " ");
				result[i][j] = mtx1[i][j] + mtx2[i][j];
			}
			// System.out.println("");

		}
		for (int i = 0; i < mtx1.length; i++) {
			for (int j = 0; j < mtx1[i].length; j++) {
				System.out.print(result[i][j] + " ");
				result[i][j] = mtx1[i][j] + mtx2[i][j];
			}
			System.out.println("");

		}

	}
}
