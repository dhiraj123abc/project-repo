package arrays;

import java.util.Scanner;

public class Check_element_present {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] element = { 10, 20, 10, 15, 2, 5, 25, 22 };
		System.out.println("enter number to check the presence of your element in the Array");
		Scanner sc = new Scanner(System.in);
		int user = sc.nextInt();
		Boolean isPresent = false;

		for (int bucket : element) {
			if (user == bucket) {
				isPresent = true;

				break;
			}

		}
		if (isPresent) {
			System.out.println("present");
		} else {
			System.out.println("not present");
		}

	}

}
