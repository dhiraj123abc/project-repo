package arrays;

public class Sort_Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[]= {5,4,2,1,6,8,2,1};
		
		inserstionSort(arr);
		for(int k=0;k<arr.length;k++) {
			System.out.print(" "+ arr[k]);
			
		}
		
	}

	private static void inserstionSort(int arr[]) {
		// TODO Auto-generated method stub
		int temp;
		int j;
		 for(int i =1;i<arr.length;i++) {
			 temp=arr[i]; //4
			 
			 j=i-1;//0
		 
		 while(j>=0 && temp< arr[j]) {
			 
			 arr[j+1]=arr[j];
			 j=j-1; //-1
			 
					 
		 }
			 arr[j+1]=temp;
			 
		 }
		
	}
	


}
