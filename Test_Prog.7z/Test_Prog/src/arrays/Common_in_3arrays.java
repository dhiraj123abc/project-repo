package arrays;

public class Common_in_3arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr1[] = { 10, 30, 50, 70, 80, 100 };
		int arr2[] = { 20, 30, 40, 50, 60, 70, 80 };
		int arr3[] = { 10, 20, 30, 70 };

		for (int i = 0; i < arr1.length; i++) {
			for (int j = 0; j < arr2.length; j++) {

				for (int k = 0; k < arr3.length; k++) {
					if (arr1[i] == arr2[j] && arr2[j] == arr3[k]) {
						System.out.println("common element " + arr3[k]);

					}

				}
			}

		}

		commonElement(arr1, arr2, arr3);
	}

	private static void commonElement(int[] arr1, int[] arr2, int[] arr3) {
		// TODO Auto-generated method stub
		System.out.println("o(n) approach ");
		int x = 0, y = 0, z = 0;
		while (x < arr1.length && y < arr2.length && z < arr3.length) {

			if (arr1[x] == arr2[y] && arr2[y] == arr3[z]) {

				System.out.println("common element " + arr2[y]);
				x++;
				y++;
				z++;

			} else if (arr1[x] > arr2[y]) {
				y++;

			} else if (arr2[y] > arr3[z]) {

				z++;
			} else {
				x++;
			}

		}

	}

}
