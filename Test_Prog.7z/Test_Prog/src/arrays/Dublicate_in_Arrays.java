package arrays;

import java.util.HashSet;
import java.util.Set;

public class Dublicate_in_Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {1,5,7,5,1,8,9,6,7};
		
		Set<Integer> set= new HashSet<>();
		//boolean isDublicate= false;
		
		for(int i=0;i<arr.length;i++) {
			if(set.contains(arr[i])) {
				//isDublicate=true;
				System.out.println("duplicate element"+ arr[i]);
				
			}
			else {
				set.add(arr[i]);
				//System.out.println(" "+ arr[i]);
				
			}
			
		}
		

	}

}
