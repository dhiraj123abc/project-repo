package arrays;

public class Pair_Sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 11;
		int arr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		// find pairs in array where sum is 10
		int start = 0;
		int end = arr.length - 1;

		while (start < end) {
			if (arr[start] + arr[end] < sum) {
				start++;
			}
			else if (arr[start] + arr[end] > sum) {
				end--;
			}
			else if (arr[start] + arr[end]== sum) {
				 System.out.println("pair("+arr[start]+","+arr[end]+")");
				 end--;
				 start++;
				 
			}
			

		}

	}

}
