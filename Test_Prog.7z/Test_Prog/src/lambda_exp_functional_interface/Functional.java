package lambda_exp_functional_interface;

import java.util.ArrayList;
import java.util.function.Function;
import java.util.function.Predicate;

class Employee {
	String name;
	int salary;
	int experince;

	public Employee(String name, int salary, int experince) {
		super();
		this.name = name;
		this.salary = salary;
		this.experince = experince;
	}

}

public class Functional {

	public static void main(String[] args) {
		ArrayList<Employee> al = new ArrayList<Employee>();
		al.add(new Employee("dhiraj", 30000, 2));
		al.add(new Employee("guluuu", 100, 2));
		al.add(new Employee("chuna", 102000, 2));
		Predicate<Integer> p = (e) -> e > 1000;
		Function<Employee, Integer> fn = e -> {
			int salary = e.salary;
			if (salary > 10000 && salary < 35000) {
				return (salary * 10 / 100);
			}
			return (salary * 10 / 100);
		};
		// Employee emp = new Employee("dhiraj",30000,2);
		// predicated returns boolean used for test cases 1 abstract method in it is
		// test
		// function <T,R>
		// cosumer accept method only sysout
		// supplier get method
		for (Employee empAll : al) {
			int bonus = fn.apply(empAll);

			if (p.test(bonus)) {

				System.out.println(
						"" + empAll.name + "  has salary more then 10000  current salary is =" + empAll.salary);
			}
		}

	}
}
