package strream_api;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

class Student {
	String name;
	int rollno;
	String grade;

	public Student(String name, int rollno, String grade) {
		super();
		this.name = name;
		this.rollno = rollno;
		this.grade = grade;
	}

}

public class flat_map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> list1 = Arrays.asList("dhiraj", "hemu");
		List<String> list2 = Arrays.asList("chada", "oho");
		List<String> list3 = Arrays.asList("nemuu", "pandqa");
		List<String> list4 = Arrays.asList("raif", "laka");

		List<List<String>> list5 = Arrays.asList(list1, list2, list3, list4);
//		list5.add(list1);
//		list5.add(list2);
//		list5.add(list3);
//		list5.add(list4);

		// before java 8
		for (List<String> newllist : list5) {
			for (String names : newllist)
				System.out.println(names);

		}
		System.out.println("//using stream ");
		// using stream
		List<String> Stir = list5.stream().flatMap(e -> e.stream()).collect(Collectors.toList());
		System.out.println("" + Stir);

		List<Student> studentlist1 = Arrays.asList(new Student("dhiraj", 145, "A+"), new Student("sawan", 146, "A+"),
				new Student("bhiu", 147, "A+")

		);

		List<Student> studentlist2 = Arrays.asList(new Student("dada", 148, "A+"), new Student("baba", 149, "B+"),
				new Student("kaka", 1455, "C+")

		);
		List<Student> studentlist3 = Arrays.asList(new Student("chacha", 500, "A+"), new Student("chachi", 526, "B+"),
				new Student("beta", 523, "C+")

		);

		List<List<Student>> studentlist = Arrays.asList(studentlist1, studentlist2, studentlist3);
		for (List<Student> s : studentlist) {

			for (Student names : s) {
				System.out.println("names are as follows " + names.name);

			}
		}

		System.out.println("using srteams now ");
		List<Integer> stnumbers = studentlist.stream()

				.flatMap(e -> e.stream()).map(d -> d.rollno).filter(d -> d > 500).collect(Collectors.toList());
		System.out.println("student rollnumbers" + stnumbers);
	}

}
