package strream_api;

import java.util.*;
import java.util.stream.Collectors;

class Employee {
	String name;
	int salary;
	int experience;

	public Employee(String name, int salary, int experience) {
		super();
		this.name = name;
		this.salary = salary;
		this.experience = experience;
	}

}

public class Streams_Api {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list = Arrays.asList(1, 2, 4, 3, 4, 6, 4, 3, 4, 36);
		List<Integer> list2 = new ArrayList<Integer>();
		list2 = list.stream().filter(p -> p > 4).collect(Collectors.toList());
		System.out.println(" using stream  value greater the 4 =" + list2);

		// object collection
		List<Employee> emplist = Arrays
				.asList
				(new Employee("dhiraj", 150000, 3), 
			    new Employee("vishwas", 120000, 2),
				new Employee("tanveer", 16000, 1),
				new Employee("dilu", 250000, 4));
		
		List<Employee> emplist2 = new ArrayList<Employee>();
		emplist.stream().filter(e -> e.experience >= 3)
				.forEach(cm -> System.out.println("name " + cm.name + " exper level " + cm.experience));
		// System.out.println("experience level above 3"+ emplist2.);
		
		System.out.println("using map concept getting salary of person having salary more then 16000 ");
	List<Integer> emplist3=  emplist.stream().filter(e->e.salary>16000).map(s->s.experience+1).collect(Collectors.toList());
System.out.println("exp level "+emplist3);
	}

}
