package com.example.springBootCRUD.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.springBootCRUD.model.Product;

@Service
public class ProductService {

	private List<Product> products = new ArrayList(Arrays.asList(new Product("121", "gemini", "oil"),
			new Product("122", "aqua", "purifier"), new Product("123", "Tv", "electronic")));

	public List<Product> getAllProducts() {
		return products;

	}

	public Product getProduct(String id) {
		return products.stream().filter(p -> p.getId().equals(id)).findFirst().get();
	}

	public void addProduct(Product product) {
		products.add(product);

	}

	public void updateProduct(String id, Product product) {
		for (int i = 0; i < products.size(); i++) {
			Product p = products.get(i);
			if (p.getId().equals(id)) {
				products.set(i, product);
				return;

			}

		}

	}

	public void deleteProduct(String id) {
		products.removeIf(p -> p.getId().equals(id));

	}
}
